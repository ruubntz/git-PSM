#include <iostream>

using namespace std;
struct mitipo {
	int a;
	double b;
	char c;
};
struct alumno {
	char nombre[10];
	int nota;
};